# Networks Project

Data analysis is done with python, and can be seen in the jupyter notebooks. 

Data generation is done with `c++`, using the code in `cpp2/main.cpp`. There are different functions to call to generate different kinds of data, the function names should be quite self explanatory (I hope).

The data was not included in the zip because it is too big. 